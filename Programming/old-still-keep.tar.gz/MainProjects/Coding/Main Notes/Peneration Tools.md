## Peneration Tool

- Nmap - 'sudo apt install nmap'
- JohntheRipper - Clone Git Repo, cd TO SRC - ./configure /make - downlaod rockyou.txt and to test it us ./john -test in /run.
- Hydra - Clone Git Repo, cd TO SRC - ./configure /make
- Gobuster - sudo apt install GoBuster
- Enu4linux
